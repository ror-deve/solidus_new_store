/**
 * Select2 English Canada translations
 */
(function ($) {
    "use strict";

    $.fn.select2.locales['en-CA'] = {};

    $.extend($.fn.select2.defaults, $.fn.select2.locales['en-CA']);
})(jQuery);
