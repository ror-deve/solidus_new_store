/**
 * Select2 English GB translations
 */
(function ($) {
    "use strict";

    $.fn.select2.locales['en-GB'] = {};

    $.extend($.fn.select2.defaults, $.fn.select2.locales['en-GB']);
})(jQuery);
