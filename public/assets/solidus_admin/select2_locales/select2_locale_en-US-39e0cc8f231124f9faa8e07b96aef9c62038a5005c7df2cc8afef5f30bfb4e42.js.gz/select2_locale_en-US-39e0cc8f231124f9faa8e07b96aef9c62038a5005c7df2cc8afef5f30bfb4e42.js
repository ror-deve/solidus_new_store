/**
 * Select2 English US translations
 */
(function ($) {
    "use strict";

    $.fn.select2.locales['en-US'] = {};

    $.extend($.fn.select2.defaults, $.fn.select2.locales['en-US']);
})(jQuery);
