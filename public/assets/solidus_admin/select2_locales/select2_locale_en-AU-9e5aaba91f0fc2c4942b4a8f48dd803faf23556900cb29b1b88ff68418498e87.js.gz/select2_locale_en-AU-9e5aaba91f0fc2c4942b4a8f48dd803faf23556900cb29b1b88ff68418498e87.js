/**
 * Select2 English Australian translations
 */
(function ($) {
    "use strict";

    $.fn.select2.locales['en-AU'] = {};

    $.extend($.fn.select2.defaults, $.fn.select2.locales['en-AU']);
})(jQuery);
