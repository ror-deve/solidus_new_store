/**
 * Select2 English IN translations
 */
(function ($) {
    "use strict";

    $.fn.select2.locales['en-IN'] = {};

    $.extend($.fn.select2.defaults, $.fn.select2.locales['en-IN']);
})(jQuery);
